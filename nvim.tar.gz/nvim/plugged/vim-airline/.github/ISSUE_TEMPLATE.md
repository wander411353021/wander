#### environment

- vim: ????
- vim-airline: ????
- OS: ????
- Have you reproduced with a minimal vimrc: ???
- What is your airline configuration: ???
if you are using terminal:
- terminal: ????
- $TERM variable: ???
- color configuration (:set t_Co?):
if you are using Neovim:
- does it happen in Vim: ???

#### actual behavior

????

#### expected behavior

????

#### screen shot (if possible)
